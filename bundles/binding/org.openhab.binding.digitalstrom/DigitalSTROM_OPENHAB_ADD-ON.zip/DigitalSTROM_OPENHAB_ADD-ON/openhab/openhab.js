var now = new Date();
var evt;

if (raisedEvent.source.isDevice) {
   evt = new Event("openhabEvent",
          {
             dsid: raisedEvent.source.dsid,
             zoneID: raisedEvent.source.zoneID,
             sceneID: raisedEvent.parameter.sceneID,
             timestamp: now.getTime(),
             isDevice: raisedEvent.source.isDevice,
          }  );

}
else
{
   evt = new Event("openhabEvent",
          {
             zoneID: raisedEvent.source.zoneID,
             groupID: raisedEvent.source.groupID,
             sceneID: raisedEvent.parameter.sceneID,
             timestamp: now.getTime(),
             isDevice: raisedEvent.source.isDevice,
          }  );
}
evt.raise();
