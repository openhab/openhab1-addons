/*
    Calimero GUI - A graphical wrapper for the Calimero tools
    Copyright (C) 2006-2008 B. Malinowsky

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package tuwien.auto.calimero.gui;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Font;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.ToolBar;
import org.eclipse.swt.widgets.ToolItem;

/**
 * @author B. Malinowsky
 */
public class TopLevelShell
{
	static Display display;
	static Shell shell;
	static Font font;

	private static Text localHost;
	private final CTabFolder tf;
	
	TopLevelShell()
	{
		shell = new Shell(display);
		shell.setSize(300, 200);
		shell.setText("Calimero  -  An open source library for KNX Access");
		shell.setLayout(new GridLayout());
	
		final ToolBar header = new ToolBar(shell, SWT.FLAT | SWT.WRAP);
		final ToolItem connect = new ToolItem(header, SWT.NONE);
		connect.setText("Connect ...");
		
		final ToolItem showLog = new ToolItem(header, SWT.NONE);
		showLog.setText("Show log");
		showLog.addSelectionListener(new SelectionAdapter()
		{
			@Override
			public void widgetSelected(final SelectionEvent e)
			{
				new LogTab(tf);
			}
		});
		
		final ToolItem about = new ToolItem(header, SWT.NONE);
		about.setText("About ...");
		about.addSelectionListener(new SelectionAdapter()
		{
			@Override
			public void widgetSelected(final SelectionEvent e)
			{
				new About(shell);
			}
		});
		
		// area for local host to use in connections
		new ToolItem(header, SWT.SEPARATOR);
		// TODO how can we vertically align the label text so it's
		// centered with the other text?
		// just use a disabled toolbar button for now
		// final Label localHostLabel = new Label(header, SWT.NONE);
		// localHostLabel.setText(" local host: ");
		final ToolItem labelItem = new ToolItem(header, SWT.NONE);
		labelItem.setText(" local host: ");
		labelItem.setEnabled(false);
		// labelItem.setControl(localHostLabel);
		Point size;
		// size = localHostLabel.computeSize(SWT.DEFAULT, SWT.DEFAULT);
		// labelItem.setWidth(size.x);
		
		localHost = new Text(header, SWT.BORDER);
		try {
			localHost.setText(InetAddress.getLocalHost().getHostAddress());
		}
		catch (final UnknownHostException e) {}
		size = localHost.computeSize(SWT.DEFAULT, SWT.DEFAULT);
		final ToolItem hostItem = new ToolItem(header, SWT.SEPARATOR);
		hostItem.setControl(localHost);
		hostItem.setWidth(size.x + 100);
		
		new Label(shell, SWT.SEPARATOR | SWT.HORIZONTAL).setLayoutData(new GridData(
			SWT.FILL, SWT.NONE, true, false));
	
		tf = new CTabFolder(shell, SWT.NONE | SWT.CAP_ROUND | SWT.BORDER);
		tf.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		tf.setUnselectedCloseVisible(false);
		tf.setSimple(false);
		tf.setMRUVisible(true);
		tf.setFont(font);
		tf.setSelectionBackground(new Color[] { display.getSystemColor(SWT.COLOR_WHITE),
			display.getSystemColor(SWT.COLOR_WIDGET_BACKGROUND), }, new int[] { 75 },
			true);
		connect.addSelectionListener(new SelectionAdapter()
		{
			@Override
			public void widgetSelected(final SelectionEvent e)
			{
				new ConnectDialog(tf, null, "", "", null, false);
			}
		});
	
		new DiscoverTab(tf);
		shell.pack();
		shell.setSize(shell.getSize().x + 80, shell.getSize().y + 100);
		shell.open();
		while (!shell.isDisposed())
			if (!display.readAndDispatch())
				display.sleep();
	}

	/**
	 * The main entry routine of the GUI.
	 * <p>
	 * 
	 * @param args none expected
	 */
	public static void main(final String[] args)
	{
		display = new Display();
		try {
			font = new Font(TopLevelShell.display, "Arial", 10, 0);
			new TopLevelShell();
		}
		finally {
			display.dispose();
		}
	}

	static String getLocalHost()
	{
		return localHost.getText();
	}
	
	static void asyncExec(final Runnable task)
	{
		if (display.isDisposed())
			return;
		display.asyncExec(task);
	}
}
