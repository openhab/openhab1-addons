/*
    Calimero GUI - A graphical wrapper for the Calimero tools
    Copyright (C) 2006-2008 B. Malinowsky

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package tuwien.auto.calimero.gui;

import java.util.ArrayList;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.events.DisposeEvent;
import org.eclipse.swt.widgets.TableColumn;

import tuwien.auto.calimero.CloseEvent;
import tuwien.auto.calimero.DataUnitBuilder;
import tuwien.auto.calimero.FrameEvent;
import tuwien.auto.calimero.cemi.CEMIBusMon;
import tuwien.auto.calimero.exception.KNXException;
import tuwien.auto.calimero.link.event.LinkListener;
import tuwien.auto.calimero.link.event.MonitorFrameEvent;
import tuwien.auto.calimero.link.medium.RawFrame;
import tuwien.auto.calimero.link.medium.RawFrameBase;
import tuwien.auto.calimero.tools.NetworkMonitor;

/**
 * @author B. Malinowsky
 */
class MonitorTab extends BaseTabLayout
{
	private NetworkMonitor m;

	MonitorTab(final CTabFolder tf, final String name, final String host,
		final String port, final boolean useNAT)
	{
		super(tf, "Monitor for " + name, "Monitoring"
			+ (host.isEmpty() ? "" : " on host " + host) + " on port " + port
			+ (useNAT ? ", using NAT" : ""));
		final TableColumn timestamp = new TableColumn(list, SWT.RIGHT);
		timestamp.setText("Timestamp");
		timestamp.setWidth(80);
		final TableColumn status = new TableColumn(list, SWT.LEFT);
		status.setText("Status / Sequence");
		status.setWidth(150);
		final TableColumn raw = new TableColumn(list, SWT.LEFT);
		raw.setText("Raw frame");
		raw.setWidth(150);
		final TableColumn decoded = new TableColumn(list, SWT.LEFT);
		decoded.setText("Decoded frame");
		decoded.setWidth(200);
		final TableColumn asdu = new TableColumn(list, SWT.LEFT);
		asdu.setText("TPCI / APCI");
		asdu.setWidth(100);
		enableColumnAdjusting();

		startMonitor(host, port, useNAT);
	}

	private void startMonitor(final String host, final String port, final boolean useNAT)
	{
		final java.util.List<String> args = new ArrayList<String>();
		if (!host.isEmpty()) {
			if (!TopLevelShell.getLocalHost().isEmpty()) {
				args.add("-localhost");
				args.add(TopLevelShell.getLocalHost());
			}
			args.add(host);
			if (useNAT)
				args.add("-nat");
			if (!port.isEmpty())
				args.add("-p");
		}
		else
			args.add("-s");
		args.add(port);

		list.removeAll();
		log.removeAll();

		final class MonitorListener implements LinkListener
		{
			public void indication(final FrameEvent e)
			{
				final java.util.List<String> item = new ArrayList<String>();
				// timestamp
				item.add(Long.toString(((CEMIBusMon) e.getFrame()).getTimestamp()));
				final String s = e.getFrame().toString();
				// status / sequence
				final String status = "status ";
				final String rawFrame = "raw frame ";
				item.add(s.substring(s.indexOf(status), s.indexOf(rawFrame)));
				// raw frame
				item.add(s.substring(s.indexOf(rawFrame) + rawFrame.length()));
				final RawFrame raw = ((MonitorFrameEvent) e).getRawFrame();
				if (raw != null) {
					// decoded raw frame
					item.add(raw.toString());
					if (raw instanceof RawFrameBase) {
						final RawFrameBase f = (RawFrameBase) raw;
						// asdu
						item.add(DataUnitBuilder.decode(f.getTPDU(), f.getDestination()));
					}
				}
				asyncAddListItem(item.toArray(new String[0]), null, null);
			}

			public void linkClosed(final CloseEvent e)
			{
				asyncAddLog("network monitor exit, " + e.getReason());
				m.quit();
			}
		}

		try {
			m = new NetworkMonitor(args.toArray(new String[0]), logWriter);
			new Thread()
			{
				{
					setDaemon(true);
				}

				@Override
				public void run()
				{
					try {
						m.run(new MonitorListener());
					}
					catch (final KNXException e) {
						asyncAddLog("error: " + e.getMessage());
					}
				}
			}.start();
		}
		catch (final Exception e) {
			log.add("error: " + e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see tuwien.auto.calimero.gui.BaseTabLayout#onDispose(
	 * org.eclipse.swt.events.DisposeEvent)
	 */
	@Override
	protected void onDispose(final DisposeEvent e)
	{
		if (m != null)
			m.quit();
	}
}
