/*
    Calimero GUI - A graphical wrapper for the Calimero tools
    Copyright (C) 2006-2008 B. Malinowsky

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package tuwien.auto.calimero.gui;

import tuwien.auto.calimero.GroupAddress;
import tuwien.auto.calimero.datapoint.DatapointMap;
import tuwien.auto.calimero.datapoint.DatapointModel;
import tuwien.auto.calimero.datapoint.StateDP;
import tuwien.auto.calimero.xml.KNXMLException;
import tuwien.auto.calimero.xml.XMLFactory;
import tuwien.auto.calimero.xml.XMLWriter;

/**
 * A small code example to show how to create and save a Calimero datapoint list.
 * 
 * @author B. Malinowsky
 */
public class CreateDatapoints
{
	private CreateDatapoints()
	{}
	
	public static void main(final String[] args)
	{
		final String[] dpt = { "1.001", "9.002", "12.001" };
		
		final DatapointModel model = new DatapointMap();
		for (int i = 0; i < dpt.length; ++i)
			model.add(new StateDP(new GroupAddress(0, 0, i + 1), "DP " + (i + 1), Integer
				.parseInt(dpt[i].substring(0, dpt[i].indexOf('.'))), dpt[i]));

		try {
			final XMLWriter w = XMLFactory.getInstance().createXMLWriter(
				"testDatapoints.xml");
			try {
				model.save(w);
			}
			finally {
				w.close();
			}
		}
		catch (final KNXMLException e) {
			System.out.println(e.getMessage());
		}
	}
}
