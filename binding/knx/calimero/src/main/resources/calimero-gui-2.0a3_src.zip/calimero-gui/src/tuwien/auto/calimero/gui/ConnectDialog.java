/*
    Calimero GUI - A graphical wrapper for the Calimero tools
    Copyright (C) 2006-2008 B. Malinowsky

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package tuwien.auto.calimero.gui;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.layout.RowData;
import org.eclipse.swt.layout.RowLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;

/**
 * @author B. Malinowsky
 */
class ConnectDialog
{
	ConnectDialog(final CTabFolder tf, final String name, final String host,
		final String port, final String mcast, final boolean useNAT)
	{
		final Shell shell = new Shell(TopLevelShell.shell, SWT.DIALOG_TRIM | SWT.RESIZE);
		shell.setLayout(new GridLayout());
		shell.setText("Open connection to ...");

		final boolean confirm = name != null;
		final boolean serial = host == null;

		final Label nameLabel = new Label(shell, SWT.NONE);
		nameLabel.setFont(TopLevelShell.font);
		nameLabel.setText(confirm ? "Name / ID: " + name
			: "Specify connection parameters.\nFor serial connections, "
				+ "leave the host empty.");

		final Composite c = new Composite(shell, SWT.NONE);
		c.setLayout(new GridLayout(2, false));
		c.setLayoutData(new GridData(SWT.FILL, SWT.NONE, true, false));
		final Label hostLabel = new Label(c, SWT.NONE);
		hostLabel.setLayoutData(new GridData(SWT.LEFT, SWT.NONE, false, false));
		hostLabel.setText("IP address / host name:");
		if (serial)
			hostLabel.setEnabled(false);

		final Text hostData = new Text(c, SWT.BORDER);
		hostData.setLayoutData(new GridData(SWT.FILL, SWT.NONE, true, false));
		if (serial)
			hostData.setEnabled(false);
		else
			hostData.setText(host);

		final Label portLabel = new Label(c, SWT.NONE);
		portLabel.setLayoutData(new GridData(SWT.LEFT, SWT.NONE, false, false));
		portLabel.setText(confirm ? serial ? "Serial port ID:" : "UDP port:"
			: "Port / ID");

		final Text portData = new Text(c, SWT.BORDER);
		portData.setLayoutData(new GridData(SWT.FILL, SWT.NONE, true, false));
		portData.setText(port);

		final Button nat = new Button(c, SWT.CHECK);
		nat.setText("use NAT aware connection");
		nat.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		if (serial)
			nat.setEnabled(false);
		else {
			nat.setToolTipText("Some KNXnet/IP devices do not support "
				+ "this mode of connection");
			nat.setSelection(useNAT);
		}

		// spacer to the right of NAT checkbox
		new Label(c, SWT.NONE);

		final Label configKNXAddress = new Label(c, SWT.NONE);
		configKNXAddress.setText("KNX address for remote config: ");
		final Text knxAddr = new Text(c, SWT.BORDER);
		knxAddr.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));

		final Composite mode = new Composite(shell, SWT.NONE);
		final RowLayout col = new RowLayout(SWT.VERTICAL);
		col.fill = true;
		col.wrap = false;
		mode.setLayout(col);

		final Button tunnel = new Button(mode, SWT.RADIO);
		tunnel.setText("open tunnel connection");
		tunnel.setSelection(true);
		final Button monitor = new Button(mode, SWT.RADIO);
		monitor.setText("open monitor connection");
		final Button routing = new Button(mode, SWT.RADIO);
		routing.setText("open routing connection");
		if (serial)
			routing.setEnabled(false);
		else {
			routing.addSelectionListener(new SelectionAdapter()
			{
				@Override
				public void widgetSelected(final SelectionEvent e)
				{
					if (routing.getSelection() && mcast != null)
						hostData.setText(mcast);
					if (!routing.getSelection())
						hostData.setText(host);
				}
			});
		}
		final Button config = new Button(mode, SWT.RADIO);
		config.setText("configure KNXnet/IP");

		final Composite buttons = new Composite(shell, SWT.NONE);
		buttons.setLayoutData(new GridData(SWT.RIGHT, SWT.BOTTOM, false, true));
		final RowLayout row = new RowLayout(SWT.HORIZONTAL);
		row.fill = true;
		row.spacing = 10;
		row.wrap = false;
		buttons.setLayout(row);

		final Button connect = new Button(buttons, SWT.NONE);
		connect.setText("Connect");
		connect.setLayoutData(new RowData());
		connect.addSelectionListener(new SelectionAdapter()
		{
			@Override
			public void widgetSelected(final SelectionEvent e)
			{
				final String h = hostData.getText();
				final String p = portData.getText();
				final String n = confirm ? name : h.isEmpty() ? p : h;
				final boolean natChecked = serial ? false : nat.getSelection();
				if (monitor.getSelection())
					new MonitorTab(tf, n, h, p, natChecked);
				else if (config.getSelection())
					new IPConfigTab(tf, n, h, p, natChecked, knxAddr.getText());
				else if (tunnel.getSelection())
					new TunnelTab(tf, n, h, p, natChecked, false);
				else if (routing.getSelection())
					new TunnelTab(tf, n, h, p, natChecked, true);
				shell.dispose();
			}
		});

		final Button cancel = new Button(buttons, SWT.NONE);
		cancel.setLayoutData(new RowData());
		cancel.setText("Cancel");
		cancel.addSelectionListener(new SelectionAdapter()
		{
			@Override
			public void widgetSelected(final SelectionEvent e)
			{
				shell.dispose();
			}
		});

		shell.setDefaultButton(connect);
		shell.pack();
		final Point size = shell.computeSize(SWT.DEFAULT, SWT.DEFAULT);
		shell.setMinimumSize(size);
		shell.setSize(size);
		shell.open();
	}
}
