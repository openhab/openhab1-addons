/*
    Calimero GUI - A graphical wrapper for the Calimero tools
    Copyright (C) 2006-2008 B. Malinowsky

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package tuwien.auto.calimero.gui;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;

import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.CTabFolder;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Event;
import org.eclipse.swt.widgets.Listener;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

import tuwien.auto.calimero.exception.KNXException;
import tuwien.auto.calimero.knxnetip.servicetype.SearchResponse;
import tuwien.auto.calimero.tools.Discover;

/**
 * @author B. Malinowsky
 */
class DiscoverTab extends BaseTabLayout
{
	private Button nat;

	DiscoverTab(final CTabFolder tf)
	{
		super(tf, "Device discovery && description", null, false);
		new TableColumn(list, SWT.LEFT);

		list.setHeaderVisible(false);
		listItemMargin = 10;
		list.addListener(SWT.MeasureItem, new Listener()
		{
			public void handleEvent(final Event event)
			{
				final TableItem item = (TableItem) event.item;
				final String text = item.getText(event.index);
				final Point size = event.gc.textExtent(text);
				event.width = size.x + 2 * listItemMargin;
				event.height = Math.max(event.height, size.y + listItemMargin);
			}
		});
		list.addListener(SWT.EraseItem, new Listener()
		{
			public void handleEvent(final Event event)
			{
				event.detail &= ~SWT.FOREGROUND;
			}
		});
		list.addListener(SWT.PaintItem, new Listener()
		{
			public void handleEvent(final Event event)
			{
				final TableItem item = (TableItem) event.item;
				final String text = item.getText(event.index);
				event.gc.drawText(text, event.x + listItemMargin, event.y, true);
			}
		});
		setListBanner("\nFound endpoints of devices (KNXnet/IP routers only) will be "
			+ "listed here.\nSelect an endpoint to open the connection dialog.");
		enableColumnAdjusting();
	}

	/* (non-Javadoc)
	 * @see tuwien.auto.calimero.gui.BaseTabLayout#createWorkAreaTop()
	 */
	@Override
	protected void initWorkAreaTop()
	{
		final Button start = new Button(workArea, SWT.PUSH);
		start.setText("Discover KNXnet/IP devices");
		start.setFont(TopLevelShell.font);
		start.addSelectionListener(new SelectionAdapter()
		{
			@Override
			public void widgetSelected(final SelectionEvent e)
			{
				discover();
			}
		});
		start.setFocus();

		nat = new Button(workArea, SWT.CHECK);
		nat.setText("be aware of NAT (Network Address Translation) during search");
		nat.setLayoutData(new GridData(GridData.FILL_HORIZONTAL));
		nat.setToolTipText("Some KNXnet/IP devices might not answer "
			+ "when using this mode");
	}

	private void discover()
	{
		final java.util.List<String> args = new ArrayList<String>();
		args.add("-s");
		if (nat.getSelection())
			args.add("-nat");
		list.removeAll();
		log.removeAll();
		try {
			final Discover d = new Discover(args.toArray(new String[0]), logWriter)
			{
				@Override
				protected void receivedSearchResponse(SearchResponse r)
				{
					final String sep = "\n";
					final StringBuilder buf = new StringBuilder();
					buf.append("Control endpoint ");
					buf.append(r.getControlEndpoint().toString()).append(sep);
					buf.append(r.getDevice().toString()).append(sep);
					buf.append("Supported service families:").append(sep).append("    ");
					buf.append(r.getServiceFamilies().toString());
					for (int i = buf.indexOf(", "); i != -1; i = buf.indexOf(", "))
						buf.replace(i, i + 2, sep + "    ");
					String mcast = null;
					try {
						mcast = InetAddress.getByAddress(
							r.getDevice().getMulticastAddress()).getHostAddress();
					}
					catch (UnknownHostException e) {}
					asyncAddListItem(new String[] { buf.toString() }, new String[] {
						"name", "host", "port", "mcast" }, new String[] {
						r.getDevice().getName(),
						r.getControlEndpoint().getAddress().getHostAddress(),
						Integer.toString(r.getControlEndpoint().getPort()), mcast });
				}
			};
			new Thread()
			{
				@Override
				public void run()
				{
					try {
						d.run();
					}
					catch (final KNXException e) {
						asyncAddLog("error: " + e.getMessage());
					}
					asyncAddLog("done with search");
				}
			}.start();
		}
		catch (final Exception e) {
			log.add("error: " + e.getMessage());
		}
	}

	/* (non-Javadoc)
	 * @see tuwien.auto.calimero.gui.BaseTabLayout#listItemSelected(
	 * org.eclipse.swt.events.SelectionEvent)
	 */
	@Override
	protected void onListItemSelected(final SelectionEvent e)
	{
		final TableItem i = (TableItem) e.item;
		new ConnectDialog(getTabFolder(), (String) i.getData("name"), (String) i
			.getData("host"), (String) i.getData("port"), (String) i.getData("mcast"),
			nat.getSelection());
	}
}
