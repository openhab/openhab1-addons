/*
    Calimero - A library for KNX network access
    Copyright (C) 2006-2008 W. Kastner

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package tuwien.auto.calimero.serial;

import gnu.io.CommPortIdentifier;
import gnu.io.NoSuchPortException;
import gnu.io.PortInUseException;
import gnu.io.SerialPort;
import gnu.io.UnsupportedCommOperationException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import tuwien.auto.calimero.exception.KNXException;

/**
 * Adapter to access a serial communication port using the rxtx library.
 * <p>
 * This file is not included in the Calimero library by default.
 * <p>
 * The rxtx library is not part of the Calimero library.<br>
 * For downloads, license, installation and usage of the rxtx library, as well as further
 * documentation, refer to the homepage of the rxtx library project, <www.rxtx.org>.
 * 
 * @author B. Malinowsky
 */
public class RxtxAdapter extends LibraryAdapter
{
	private static final int OPEN_TIMEOUT = 200;

	private SerialPort port;
	private InputStream is;
	private OutputStream os;

	/**
	 * Creates a new rxtx library adapter, and opens a serial port using a port identifier
	 * and baud rate.
	 * <p>
	 * 
	 * @param portID port identifier of the serial communication port to use
	 * @param baudrate baud rate to use for communication, 0 &lt; baud rate
	 * @throws KNXException
	 */
	public RxtxAdapter(String portID, int baudrate) throws KNXException
	{
		open(portID, baudrate);
	}

	public void setBaudRate(int baudrate)
	{
		try {
			port.setSerialPortParams(baudrate, SerialPort.DATABITS_8,
				SerialPort.STOPBITS_1, SerialPort.PARITY_EVEN);
		}
		catch (UnsupportedCommOperationException e) {
			logger.error("failed to configure port settings");
		}
	}

	public int getBaudRate()
	{
		return port.getBaudRate();
	}

	public InputStream getInputStream()
	{
		return is;
	}

	public OutputStream getOutputStream()
	{
		return os;
	}

	public void close()
	{
		port.close();
	}

	private void open(String portID, int baudrate) throws KNXException
	{
		logger.info("using rxtx library for serial port access");
		try {
			// rxtx does not recognize the Windows prefix for a resource name
			if (portID.startsWith("\\\\.\\"))
				portID = portID.substring(4);
			CommPortIdentifier id = CommPortIdentifier.getPortIdentifier(portID);
			if (id.getPortType() != CommPortIdentifier.PORT_SERIAL)
				throw new KNXException(portID + " is not a serial port ID");
			port = (SerialPort) id.open("Calimero FT1.2", OPEN_TIMEOUT);
			port.setFlowControlMode(SerialPort.FLOWCONTROL_NONE);
			port.enableReceiveThreshold(1024);
			// required to allow a close of the rxtx port, otherwise a read could lock
			try {
				port.enableReceiveTimeout(250);
			}
			catch (UnsupportedCommOperationException e) {
				logger.warn("no timeout support: serial port might hang during close");
			}			
			setBaudRate(baudrate);
			logger.info("setup serial port: baudrate " + port.getBaudRate()
				+ ", parity even, databits " + port.getDataBits() + ", stopbits "
				+ port.getStopBits() + ", flow control " + port.getFlowControlMode());
			is = port.getInputStream();
			os = port.getOutputStream();
			/*
			// Note: tracing of events serves informational purposes only
			try {
				port.notifyOnBreakInterrupt(true);
				port.notifyOnCarrierDetect(true);
				port.notifyOnCTS(true);
				port.notifyOnDataAvailable(true);
				port.notifyOnDSR(true);
				port.notifyOnFramingError(true);
				port.notifyOnOutputEmpty(true);
				port.notifyOnOverrunError(true);
				port.notifyOnParityError(true);
				port.notifyOnRingIndicator(true);
				port.addEventListener(new SerialPortEventListener() {
					public void serialEvent(SerialPortEvent ev) {
						int type = ev.getEventType();
						if (type == SerialPortEvent.BI)
							System.out.println("SerialPortEvent.BI");
						if (type == SerialPortEvent.CD)
							System.out.println("SerialPortEvent.CD");
						if (type == SerialPortEvent.CTS)
							System.out.println("SerialPortEvent.CTS");
						if (type == SerialPortEvent.DATA_AVAILABLE)
							System.out.println("SerialPortEvent.DATA_AVAILABLE");
						if (type == SerialPortEvent.DSR)
							System.out.println("SerialPortEvent.DSR");
						if (type == SerialPortEvent.FE)
							System.out.println("SerialPortEvent.FE");
						if (type == SerialPortEvent.OE)
							System.out.println("SerialPortEvent.OE");
						if (type == SerialPortEvent.OUTPUT_BUFFER_EMPTY)
							System.out.println("SerialPortEvent.OUTPUT_BUFFER_EMPTY");
						if (type == SerialPortEvent.PE)
							System.out.println("SerialPortEvent.PE");
						if (type == SerialPortEvent.RI)
							System.out.println("SerialPortEvent.RI");
					}
				});
			} catch (TooManyListenersException e) {	}
			*/
			return;
		}
		catch (NoSuchPortException e) {
			logger.error("serial port " + portID + " not found");
		}
		catch (PortInUseException e) {
			logger.error("serial port " + portID + " in use, " + e.getMessage());
		}
		catch (IOException e) {
			logger.error("failed to open port streams, " + e.getMessage());
		}
		catch (UnsupportedCommOperationException e) {
			logger.error("failed to configure port settings");
		}
		port.close();
		try {
			is.close();
			os.close();
		}
		catch (Exception mainlyNPE) {}
		throw new KNXException("failed to open serial port " + portID);
	}
}
